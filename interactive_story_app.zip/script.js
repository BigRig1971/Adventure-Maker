function generateInteractiveStory() {
  const input = document.getElementById("storyInput").value;
  const display = document.getElementById("storyDisplay");
  display.innerHTML = "";

  const segments = input.split(". ").slice(0, 3); // Take first 3 sentences
  let currentSegment = 0;

  function showSegment(index) {
    display.innerHTML = `<p>${segments[index]}</p>`;
    const choices = [
      `What if the character chooses a bold path?`,
      `What if the character plays it safe?`
    ];

    choices.forEach((choice, i) => {
      const choiceElem = document.createElement("div");
      choiceElem.className = "choice";
      choiceElem.textContent = choice;
      choiceElem.onclick = () => {
        if (index + 1 < segments.length) {
          showSegment(index + 1);
        } else {
          display.innerHTML = "<p>The End. Thanks for playing!</p>";
        }
      };
      display.appendChild(choiceElem);
    });
  }

  showSegment(currentSegment);
}
